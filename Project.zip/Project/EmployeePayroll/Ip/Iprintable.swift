//
//  File.swift
//  EmployeePayroll
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

protocol iPrintable
{
    
    func printMyData()
    
}

